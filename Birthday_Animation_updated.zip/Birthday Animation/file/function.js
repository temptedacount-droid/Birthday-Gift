

// variables
var $win = $(window);
var clientWidth = $win.width();
var clientHeight = $win.height();

// ---- responsive layout (added) ----
var LOGICAL_W = 1100, LOGICAL_H = 680;   // drawing coordinate space (unchanged)
var TREE_X = 240, TREE_W = 610;          // part of the canvas that holds the tree
var MOBILE_MAX = 900;                    // below this width -> phone/tablet layout
window.layoutScale = 1;
window.layoutMobile = undefined;

function applyLayout() {
    var vw = document.documentElement.clientWidth || $win.width();
    var vh = window.innerHeight || $win.height();
    var mobile = vw < MOBILE_MAX;
    var cropX = mobile ? TREE_X : 0;
    var cropW = mobile ? TREE_W : LOGICAL_W;
    var s = Math.min(1, vw / cropW);
    if (mobile) { s = Math.min(s, vh * 0.85 / LOGICAL_H); }
    window.layoutScale = s;
    window.layoutMobile = mobile;

    $('#stage').css({ width: cropW * s, height: LOGICAL_H * s });
    $('#wrap').css({ transform: 'translateX(' + (-cropX * s) + 'px) scale(' + s + ')' });

    var $text = $('#text');
    if (mobile && !$text.hasClass('mobile')) {
        $text.addClass('mobile').insertAfter('#stage');
    } else if (!mobile && $text.hasClass('mobile')) {
        $text.removeClass('mobile').prependTo('#wrap');
    }
}

$(window).resize(function() {
    var wasMobile = window.layoutMobile;
    applyLayout();
    if (wasMobile !== undefined && window.layoutMobile !== wasMobile) {
        location.reload();   // phone <-> desktop layout switch: restart animation
    }
});

(function($) {
	// Smooth typewriter: every character fades in on its own, timing is
	// frame-based (requestAnimationFrame) and the layout never jumps.
	$.fn.typewriter = function(onDone) {
		var CHAR_DELAY = 55;    // ms between characters
		var LINE_PAUSE = 320;   // extra pause at the end of each line
		this.each(function() {
			var root = this, items = [];

			// wrap every visible character in a span (Array.from keeps emojis whole)
			(function wrap(node) {
				Array.prototype.slice.call(node.childNodes).forEach(function(child) {
					if (child.nodeType === 3) {
						if (!child.nodeValue.replace(/\s+/g, '')) { return; }
						var frag = document.createDocumentFragment();
						Array.from(child.nodeValue).forEach(function(ch) {
							var span = document.createElement('span');
							span.className = 'tw-ch';
							span.textContent = ch;
							frag.appendChild(span);
							items.push(span);
						});
						node.replaceChild(frag, child);
					} else if (child.nodeName === 'BR') {
						items.push('pause');
					} else if (child.nodeType === 1) {
						wrap(child);
					}
				});
			})(root);

			var cursor = document.createElement('span');
			cursor.className = 'tw-cursor';
			var i = 0, nextAt = null;

			function tick(now) {
				if (nextAt === null) { nextAt = now; }
				while (i < items.length && now >= nextAt) {
					var item = items[i++];
					if (item === 'pause') {
						nextAt += LINE_PAUSE;
					} else {
						item.className = 'tw-ch tw-on';
						item.parentNode.insertBefore(cursor, item.nextSibling);
						nextAt += CHAR_DELAY;
					}
				}
				if (i < items.length) {
					requestAnimationFrame(tick);
				} else {
					setTimeout(function() {
						if (cursor.parentNode) { cursor.parentNode.removeChild(cursor); }
						if (typeof onDone === 'function') { onDone(); }
					}, 700);
				}
			}
			requestAnimationFrame(tick);
		});
		return this;
	};
})(jQuery);

function timeElapse(date){
	var current = Date();
	var seconds = (Date.parse(current) - Date.parse(date)) / 1000;
	var days = Math.floor(seconds / (3600 * 24));
	seconds = seconds % (3600 * 24);
	var hours = Math.floor(seconds / 3600);
	if (hours < 10) {
		hours = "0" + hours;
	}
	seconds = seconds % 3600;
	var minutes = Math.floor(seconds / 60);
	if (minutes < 10) {
		minutes = "0" + minutes;
	}
	seconds = seconds % 60;
	if (seconds < 10) {
		seconds = "0" + seconds;
	}
	var result = "Days <span class=\"digit\">" + days + "</span> Hours <span class=\"digit\">" + hours + "</span> Minutes <span class=\"digit\">" + minutes; 
	$("#clock").html(result);

	var text = "THE WORLD JUST GOT LUCKIER SINCE ";
	$("#message-box").html(text);

}